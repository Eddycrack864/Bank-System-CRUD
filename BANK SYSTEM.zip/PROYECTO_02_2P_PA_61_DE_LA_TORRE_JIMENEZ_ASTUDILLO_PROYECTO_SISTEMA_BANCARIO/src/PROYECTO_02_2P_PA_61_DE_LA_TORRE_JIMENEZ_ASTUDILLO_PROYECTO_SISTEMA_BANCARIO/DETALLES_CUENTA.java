package PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO;
import java.sql.*;
import javax.swing.*;
public class DETALLES_CUENTA extends javax.swing.JFrame {

   
    public DETALLES_CUENTA() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelDetallesCuenta = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jLabelicon = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelTipoCuenta = new javax.swing.JLabel();
        jLabelSaldo = new javax.swing.JLabel();
        jTextFieldAccType = new javax.swing.JTextField();
        jTextFieldIDUser = new javax.swing.JTextField();
        jButton1Cancel = new javax.swing.JButton();
        jButton2Submit = new javax.swing.JButton();
        jLabelID = new javax.swing.JLabel();
        jTextFieldBal1 = new javax.swing.JTextField();
        jLabelslogan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(539, 62));

        jLabelDetallesCuenta.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelDetallesCuenta.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDetallesCuenta.setText("DETALLES DE LA CUENTA");

        jLabelClose.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(254, 254, 254));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(255, 250, 250));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jLabelicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO/icon.png"))); // NOI18N
        jLabelicon.setText("jLabel3");
        jLabelicon.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelicon, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelDetallesCuenta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDetallesCuenta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelicon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabelTipoCuenta.setBackground(new java.awt.Color(236, 240, 241));
        jLabelTipoCuenta.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelTipoCuenta.setForeground(new java.awt.Color(255, 0, 0));
        jLabelTipoCuenta.setText("TIPO DE CUENTA:");

        jLabelSaldo.setBackground(new java.awt.Color(236, 240, 241));
        jLabelSaldo.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelSaldo.setForeground(new java.awt.Color(255, 0, 0));
        jLabelSaldo.setText("SALDO:");

        jTextFieldAccType.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldAccType.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldAccType.setForeground(new java.awt.Color(0, 0, 0));

        jTextFieldIDUser.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldIDUser.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldIDUser.setForeground(new java.awt.Color(0, 0, 0));

        jButton1Cancel.setBackground(new java.awt.Color(255, 0, 0));
        jButton1Cancel.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButton1Cancel.setForeground(new java.awt.Color(255, 255, 255));
        jButton1Cancel.setText("REGRESAR");
        jButton1Cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1CancelMouseClicked(evt);
            }
        });
        jButton1Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1CancelActionPerformed(evt);
            }
        });

        jButton2Submit.setBackground(new java.awt.Color(0, 0, 0));
        jButton2Submit.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButton2Submit.setForeground(new java.awt.Color(255, 255, 255));
        jButton2Submit.setText("CONTINUAR");
        jButton2Submit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2SubmitMouseClicked(evt);
            }
        });
        jButton2Submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2SubmitActionPerformed(evt);
            }
        });

        jLabelID.setBackground(new java.awt.Color(236, 240, 241));
        jLabelID.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelID.setForeground(new java.awt.Color(255, 0, 0));
        jLabelID.setText("ID:");

        jTextFieldBal1.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldBal1.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldBal1.setForeground(new java.awt.Color(0, 0, 0));

        jLabelslogan.setBackground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelslogan.setForeground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setText("Suponer lo peor y hacer lo mejor, es el método de un verdadero estratega.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelSaldo)
                            .addComponent(jLabelTipoCuenta)
                            .addComponent(jLabelID))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jTextFieldAccType, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldBal1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldIDUser, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jButton1Cancel)
                        .addGap(53, 53, 53)
                        .addComponent(jButton2Submit))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jLabelslogan)))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldAccType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelTipoCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelSaldo)
                    .addComponent(jTextFieldBal1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelID)
                    .addComponent(jTextFieldIDUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2Submit)
                    .addComponent(jButton1Cancel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(jLabelslogan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public Connection getConnection()
    {
        Connection con;
        try
        {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank2?autoReconnect=true", "root", "");
            return con;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void executeSqlQuery(String query,String message)
    {
        Connection con=getConnection();
        Statement st;
        try
        {
            st=con.createStatement();
            if(st.executeUpdate(query)==1)
            {
                JOptionPane.showMessageDialog(null,"Registrado Correctamente");
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Ha Ocurrido un Problema");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void nextPage()
    {
         PAGINA_INICIO_SESION lp= new PAGINA_INICIO_SESION();
        lp.setVisible(true);
        lp.pack();
        lp.setLocationRelativeTo(null);
        lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.dispose();
    }
   
    public void insertInAccount()
    {
        int Balance=Integer.parseInt(jTextFieldBal1.getText());
        if(Balance< 10000)
            JOptionPane.showMessageDialog(this,"SE NECESITA 10000 DE SALDO PARA CREAR UNA CUENTA");
        else
        {
        String query ="insert into Account (Account_type, Balance, Aadhar_no) values ('"+jTextFieldAccType.getText()+"','"+Balance+"','"+jTextFieldIDUser.getText()+"')";
        executeSqlQuery(query,"ACCOUNT DETAILS");}
    }
   
    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelCloseMouseClicked

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jButton1CancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1CancelMouseClicked
      
    }//GEN-LAST:event_jButton1CancelMouseClicked

    private void jButton2SubmitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2SubmitMouseClicked

      

    }//GEN-LAST:event_jButton2SubmitMouseClicked

    private void jButton1CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1CancelActionPerformed
        
        DETALLES_CUENTA ad=new DETALLES_CUENTA();
        ad.setVisible(true);
        ad.pack();
        ad.setLocationRelativeTo(null);
        ad.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButton1CancelActionPerformed

    private void jButton2SubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2SubmitActionPerformed

       insertInAccount();
        nextPage();
    }//GEN-LAST:event_jButton2SubmitActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DETALLES_CUENTA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1Cancel;
    private javax.swing.JButton jButton2Submit;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelDetallesCuenta;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelSaldo;
    private javax.swing.JLabel jLabelTipoCuenta;
    private javax.swing.JLabel jLabelicon;
    private javax.swing.JLabel jLabelslogan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextFieldAccType;
    private javax.swing.JTextField jTextFieldBal1;
    private javax.swing.JTextField jTextFieldIDUser;
    // End of variables declaration//GEN-END:variables
}
