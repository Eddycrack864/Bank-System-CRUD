package PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;
public class REGISTRARSE extends javax.swing.JFrame {

    public REGISTRARSE() {
        initComponents();
                this.setLocationRelativeTo(null);
    }
    
    public Connection getConnection()
    {
        try
        {
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank2?autoReconnect=true", "root", "");
            return con;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void executeSqlQuery(String query,String message)
    {
        Connection con=getConnection();
        Statement st;
        try
        {
            st=con.createStatement();
            if(st.executeUpdate(query)==1)
            {
                JOptionPane.showMessageDialog(null,"Ingresado con Exito");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Ha Ocurrido un Problema");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void insertInCustomer()
    {      
        String query="insert into Customer (FName,LName,Address,Email,Phone_no,Aadhar_no,DOB,Gender,Username) values ('"+jTextFieldFName.getText()+"','"+jTextFieldLName.getText()+"','"+jTextAreaAddress.getText()+"','"+jTextFieldEmail.getText()+"','"+jTextFieldPhone.getText()+"','"+jTextFieldIDUser.getText()+"','"+jTextFieldDob.getText()+"','"+jTextFieldGender.getText()+"','"+jTextFieldUser.getText()+"')";
        executeSqlQuery(query,"PERSONAL DETAILS");
        DETALLES_CUENTA ac= new DETALLES_CUENTA();        
        ac.setVisible(true);
        ac.pack();
        ac.setLocationRelativeTo(null);
        ac.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    } 
    
    public void insertInUser()
    {
        String query1 = "insert into User(Username, Password) values ('"+jTextFieldUser.getText()+"', '"+jPasswordFieldPass1.getText()+"')";
        executeSqlQuery(query1,"USER DETAILS");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelRegistrarse = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelNombre = new javax.swing.JLabel();
        jTextFieldFName = new javax.swing.JTextField();
        jPasswordFieldPass1 = new javax.swing.JPasswordField();
        jButtonRegresar = new javax.swing.JButton();
        jButtonContinuar = new javax.swing.JButton();
        jPasswordFieldPass2 = new javax.swing.JPasswordField();
        jLabelApellido = new javax.swing.JLabel();
        jLabelDireccion = new javax.swing.JLabel();
        jLabelCorreo = new javax.swing.JLabel();
        jLabelTelefono = new javax.swing.JLabel();
        jLabelID = new javax.swing.JLabel();
        jLabelFechaNacimiento = new javax.swing.JLabel();
        jLabelGenero = new javax.swing.JLabel();
        jLabelNombreUsuario = new javax.swing.JLabel();
        jLabelClave = new javax.swing.JLabel();
        jLabelConfirmarClave = new javax.swing.JLabel();
        jTextFieldLName = new javax.swing.JTextField();
        jTextFieldPhone = new javax.swing.JTextField();
        jTextFieldIDUser = new javax.swing.JTextField();
        jTextFieldEmail = new javax.swing.JTextField();
        jTextFieldDob = new javax.swing.JTextField();
        jTextFieldUser = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaAddress = new javax.swing.JTextArea();
        jTextFieldGender = new javax.swing.JTextField();
        jLabelALIniciarSesion = new javax.swing.JLabel();
        jLabelicon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLabelRegistrarse.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelRegistrarse.setForeground(new java.awt.Color(254, 254, 254));
        jLabelRegistrarse.setText("REGISTRARSE");

        jLabelClose.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(254, 254, 254));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(255, 250, 250));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabelNombre.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNombre.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelNombre.setForeground(new java.awt.Color(255, 0, 0));
        jLabelNombre.setText("NOMBRE:");

        jTextFieldFName.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldFName.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldFName.setForeground(new java.awt.Color(0, 0, 0));

        jPasswordFieldPass1.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordFieldPass1.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jPasswordFieldPass1.setForeground(new java.awt.Color(0, 0, 0));

        jButtonRegresar.setBackground(new java.awt.Color(255, 0, 0));
        jButtonRegresar.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonRegresar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRegresar.setText("REGRESAR");
        jButtonRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonRegresarMouseClicked(evt);
            }
        });

        jButtonContinuar.setBackground(new java.awt.Color(0, 0, 0));
        jButtonContinuar.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonContinuar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonContinuar.setText("CONTINUAR");
        jButtonContinuar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonContinuarMouseClicked(evt);
            }
        });
        jButtonContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonContinuarActionPerformed(evt);
            }
        });

        jPasswordFieldPass2.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordFieldPass2.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jPasswordFieldPass2.setForeground(new java.awt.Color(0, 0, 0));

        jLabelApellido.setBackground(new java.awt.Color(236, 240, 241));
        jLabelApellido.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelApellido.setForeground(new java.awt.Color(255, 0, 0));
        jLabelApellido.setText("APELLIDO:");

        jLabelDireccion.setBackground(new java.awt.Color(236, 240, 241));
        jLabelDireccion.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelDireccion.setForeground(new java.awt.Color(255, 0, 0));
        jLabelDireccion.setText("DIRECCIÓN:");

        jLabelCorreo.setBackground(new java.awt.Color(236, 240, 241));
        jLabelCorreo.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelCorreo.setForeground(new java.awt.Color(255, 0, 0));
        jLabelCorreo.setText("E - MAIL:");

        jLabelTelefono.setBackground(new java.awt.Color(236, 240, 241));
        jLabelTelefono.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelTelefono.setForeground(new java.awt.Color(255, 0, 0));
        jLabelTelefono.setText("TELÉFONO:");

        jLabelID.setBackground(new java.awt.Color(236, 240, 241));
        jLabelID.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelID.setForeground(new java.awt.Color(255, 0, 0));
        jLabelID.setText("ID:");

        jLabelFechaNacimiento.setBackground(new java.awt.Color(236, 240, 241));
        jLabelFechaNacimiento.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelFechaNacimiento.setForeground(new java.awt.Color(255, 0, 0));
        jLabelFechaNacimiento.setText("FECHA DE NACIMIENTO:");

        jLabelGenero.setBackground(new java.awt.Color(236, 240, 241));
        jLabelGenero.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelGenero.setForeground(new java.awt.Color(255, 0, 0));
        jLabelGenero.setText("GÉNERO:");

        jLabelNombreUsuario.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNombreUsuario.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelNombreUsuario.setForeground(new java.awt.Color(255, 0, 0));
        jLabelNombreUsuario.setText("NOMBRE DE USUARIO:");

        jLabelClave.setBackground(new java.awt.Color(236, 240, 241));
        jLabelClave.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelClave.setForeground(new java.awt.Color(255, 0, 0));
        jLabelClave.setText("CONTRASEÑA (6 DÍGITOS):");

        jLabelConfirmarClave.setBackground(new java.awt.Color(236, 240, 241));
        jLabelConfirmarClave.setFont(new java.awt.Font("Ubuntu Light", 1, 14)); // NOI18N
        jLabelConfirmarClave.setForeground(new java.awt.Color(255, 0, 0));
        jLabelConfirmarClave.setText("CONFIRMAR CONTRASEÑA:");

        jTextFieldLName.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldLName.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldLName.setForeground(new java.awt.Color(0, 0, 0));

        jTextFieldPhone.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldPhone.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldPhone.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldPhone.setText("Debe tener 10 dígitos");

        jTextFieldIDUser.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldIDUser.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldIDUser.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldIDUser.setText("Debe contener 12 dígitos");
        jTextFieldIDUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldIDUserActionPerformed(evt);
            }
        });

        jTextFieldEmail.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldEmail.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldEmail.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldEmail.setText("Debe contener @");

        jTextFieldDob.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldDob.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldDob.setForeground(new java.awt.Color(0, 0, 0));
        jTextFieldDob.setText("YYYY-MM-DD");

        jTextFieldUser.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldUser.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldUser.setForeground(new java.awt.Color(0, 0, 0));

        jTextAreaAddress.setBackground(new java.awt.Color(108, 122, 137));
        jTextAreaAddress.setColumns(20);
        jTextAreaAddress.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextAreaAddress.setForeground(new java.awt.Color(0, 0, 0));
        jTextAreaAddress.setRows(5);
        jScrollPane1.setViewportView(jTextAreaAddress);

        jTextFieldGender.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldGender.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldGender.setForeground(new java.awt.Color(0, 0, 0));

        jLabelALIniciarSesion.setBackground(new java.awt.Color(236, 240, 241));
        jLabelALIniciarSesion.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelALIniciarSesion.setForeground(new java.awt.Color(255, 0, 0));
        jLabelALIniciarSesion.setText("CLICK PARA INICIAR SESIÓN");
        jLabelALIniciarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelALIniciarSesionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelApellido)
                            .addComponent(jLabelNombre)
                            .addComponent(jLabelDireccion)
                            .addComponent(jLabelCorreo)
                            .addComponent(jLabelTelefono)
                            .addComponent(jLabelID)
                            .addComponent(jLabelFechaNacimiento)
                            .addComponent(jLabelGenero)
                            .addComponent(jLabelNombreUsuario)
                            .addComponent(jLabelClave)
                            .addComponent(jLabelConfirmarClave))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPasswordFieldPass1)
                            .addComponent(jPasswordFieldPass2)
                            .addComponent(jTextFieldFName)
                            .addComponent(jTextFieldLName)
                            .addComponent(jTextFieldPhone)
                            .addComponent(jTextFieldIDUser)
                            .addComponent(jTextFieldDob)
                            .addComponent(jTextFieldUser)
                            .addComponent(jTextFieldEmail)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jTextFieldGender))
                        .addContainerGap(54, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonRegresar)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonContinuar)
                        .addGap(52, 52, 52))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(jLabelALIniciarSesion)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre)
                    .addComponent(jTextFieldFName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelApellido)
                    .addComponent(jTextFieldLName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelDireccion)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelCorreo)
                    .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelTelefono))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelID)
                    .addComponent(jTextFieldIDUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldDob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelFechaNacimiento))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelGenero)
                    .addComponent(jTextFieldGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombreUsuario)
                    .addComponent(jTextFieldUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelClave)
                    .addComponent(jPasswordFieldPass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelConfirmarClave)
                    .addComponent(jPasswordFieldPass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonContinuar)
                    .addComponent(jButtonRegresar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelALIniciarSesion)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jLabelicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO/icon.png"))); // NOI18N
        jLabelicon.setText("jLabel3");
        jLabelicon.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelicon, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelRegistrarse)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelicon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelRegistrarse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelCloseMouseClicked

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jButtonRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonRegresarMouseClicked
        PAGINA_INICIO_SESION lp=new PAGINA_INICIO_SESION();
        lp.setVisible(true);
        lp.pack();
        lp.setLocationRelativeTo(null);
        lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButtonRegresarMouseClicked

    private void jLabelALIniciarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelALIniciarSesionMouseClicked
        PAGINA_INICIO_SESION lp=new PAGINA_INICIO_SESION();
        lp.setVisible(true);
        lp.pack();
        lp.setLocationRelativeTo(null);
        lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jLabelALIniciarSesionMouseClicked

    private void jButtonContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonContinuarActionPerformed
        String x=jTextFieldIDUser.getText();
        String s111=jTextFieldPhone.getText();
        int l1=s111.length();
        String A=jTextFieldIDUser.getText();
        int l2=A.length();
        String Fname=jTextFieldFName.getText();
        String Lname=jTextFieldLName.getText();
        Pattern p=Pattern.compile("[@]",Pattern.CASE_INSENSITIVE);
        Matcher m=p.matcher(jTextFieldEmail.getText());
        Boolean b=m.find();
        String DOB1=jTextFieldDob.getText();
        String DOB2="2018";
        String DOB3="2017-11";
        String DOB4="2017-12";
        String DOB5="2017/11";
        String DOB6="2017/12";
        String s1=jPasswordFieldPass1.getText();
        int p1=s1.length();
        String s2=jPasswordFieldPass2.getText();
        if(x.length()!=12 && l1!=10 || Fname.matches(".*\\d.*") || Lname.matches(".*\\d.*") || !b || DOB1.contains(DOB2) || DOB1.contains(DOB3) || DOB1.contains(DOB4) || DOB1.contains(DOB5) || DOB1.contains(DOB6) || !s1.equals(s2) || p1!=6)
        {            
            if(x.length()!=12)
                JOptionPane.showMessageDialog(this,"Porfavor Ingrese un ID de 12 Dígitos");
            if(l1!=10)
                JOptionPane.showMessageDialog(this,"Porfavor Ingrese un Número Telefónico de 10 Dígitos");    
            if(Fname.matches(".*\\d.*"))
                JOptionPane.showMessageDialog(this,"Porfavor Ingrese su Nombre Correctamente");
            if(Lname.matches(".*\\d.*"))
                JOptionPane.showMessageDialog(this,"Porfavor Ingrese su Apellido Correctamente");
            if(!b)
                JOptionPane.showMessageDialog(this,"Su E - MAIL debe tener un signo @");
            if(DOB1.contains(DOB2) || DOB1.contains(DOB3)|| DOB1.contains(DOB4)|| DOB1.contains(DOB5) || DOB1.contains(DOB6))
                JOptionPane.showMessageDialog(this,"Porfavor Ingrese una Fecha de Nacimiento Válida");
            if(!s1.equals(s2))
                JOptionPane.showMessageDialog(null, "Porfavor Escriba la Contraseña Correctamente");
            if(p1!=6)
                JOptionPane.showMessageDialog(null, "La Contraseña Debe Tener 6 Caracteres");
        }
        else
        {
            insertInUser();
            insertInCustomer();
        }
    }//GEN-LAST:event_jButtonContinuarActionPerformed

    private void jButtonContinuarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonContinuarMouseClicked

    
    }//GEN-LAST:event_jButtonContinuarMouseClicked

    private void jTextFieldIDUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldIDUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldIDUserActionPerformed

    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new REGISTRARSE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonContinuar;
    private javax.swing.JButton jButtonRegresar;
    private javax.swing.JLabel jLabelALIniciarSesion;
    private javax.swing.JLabel jLabelApellido;
    private javax.swing.JLabel jLabelClave;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelConfirmarClave;
    private javax.swing.JLabel jLabelCorreo;
    private javax.swing.JLabel jLabelDireccion;
    private javax.swing.JLabel jLabelFechaNacimiento;
    private javax.swing.JLabel jLabelGenero;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelNombreUsuario;
    private javax.swing.JLabel jLabelRegistrarse;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelicon;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordFieldPass1;
    private javax.swing.JPasswordField jPasswordFieldPass2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaAddress;
    private javax.swing.JTextField jTextFieldDob;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldFName;
    private javax.swing.JTextField jTextFieldGender;
    private javax.swing.JTextField jTextFieldIDUser;
    private javax.swing.JTextField jTextFieldLName;
    private javax.swing.JTextField jTextFieldPhone;
    private javax.swing.JTextField jTextFieldUser;
    // End of variables declaration//GEN-END:variables
}
