package PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO;
import java.sql.*;
import javax.swing.*;

public class CAMBIAR_CLAVE extends javax.swing.JFrame {

    public static String u;

    public CAMBIAR_CLAVE() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    public Connection getConnection() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank2?autoReconnect=true", "root", "");
            return con;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public void executeSqlQuery(String query, String message) {
        Connection con = getConnection();
        Statement st;
        try {
            st = con.createStatement();
            if (st.executeUpdate(query) == 1) {
                JOptionPane.showMessageDialog(null, "Contraseña Cambiada Correctamente");
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese los Datos Requeridos");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Update() {
        String p = jPasswordFieldPass.getText();
        String s2 = jPasswordFieldPass1.getText();
        String u = jTextFieldUsername.getText();
        if (p.equals(s2)) 
        {
            String query1 = "Update User Set Password='" + p + "' where Username= '" + u + "'";
            executeSqlQuery(query1, "UPDATED");
            PAGINA_INICIO_SESION lp = new PAGINA_INICIO_SESION();
            lp.setVisible(true);
            lp.pack();
            lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.dispose();
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Porfavor Escriba la Contraseña Correcta");
            CAMBIAR_CLAVE up = new CAMBIAR_CLAVE();
            up.setVisible(true);
            up.pack();
            up.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.dispose();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelOlvidadaPassword = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jLabelicon = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelPassword = new javax.swing.JLabel();
        jLabelNombreUsuario = new javax.swing.JLabel();
        jPasswordFieldPass = new javax.swing.JPasswordField();
        jButtonRegresar = new javax.swing.JButton();
        jButtonContinuar = new javax.swing.JButton();
        jLabelConfirmaPassword = new javax.swing.JLabel();
        jPasswordFieldPass1 = new javax.swing.JPasswordField();
        jTextFieldUsername = new javax.swing.JTextField();
        jLabelslogan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(352, 62));

        jLabelOlvidadaPassword.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelOlvidadaPassword.setForeground(new java.awt.Color(254, 254, 254));
        jLabelOlvidadaPassword.setText("CONTRASEÑA OLVIDADA");

        jLabelClose.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(254, 254, 254));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(255, 250, 250));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jLabelicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO/icon.png"))); // NOI18N
        jLabelicon.setText("jLabel3");
        jLabelicon.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelicon, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabelOlvidadaPassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelOlvidadaPassword, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelicon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabelPassword.setBackground(new java.awt.Color(236, 240, 241));
        jLabelPassword.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelPassword.setForeground(new java.awt.Color(0, 0, 0));
        jLabelPassword.setText("CONTRASEÑA:");

        jLabelNombreUsuario.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNombreUsuario.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelNombreUsuario.setForeground(new java.awt.Color(0, 0, 0));
        jLabelNombreUsuario.setText("NOMBRE DE USUARIO:");

        jPasswordFieldPass.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordFieldPass.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jPasswordFieldPass.setForeground(new java.awt.Color(0, 0, 0));

        jButtonRegresar.setBackground(new java.awt.Color(255, 0, 0));
        jButtonRegresar.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonRegresar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRegresar.setText("REGRESAR");
        jButtonRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonRegresarMouseClicked(evt);
            }
        });
        jButtonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegresarActionPerformed(evt);
            }
        });

        jButtonContinuar.setBackground(new java.awt.Color(0, 0, 0));
        jButtonContinuar.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonContinuar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonContinuar.setText("CONTINUAR");
        jButtonContinuar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonContinuarMouseClicked(evt);
            }
        });
        jButtonContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonContinuarActionPerformed(evt);
            }
        });

        jLabelConfirmaPassword.setBackground(new java.awt.Color(236, 240, 241));
        jLabelConfirmaPassword.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelConfirmaPassword.setForeground(new java.awt.Color(0, 0, 0));
        jLabelConfirmaPassword.setText("CONFIRME LA CONTRASEÑA:");

        jPasswordFieldPass1.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordFieldPass1.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jPasswordFieldPass1.setForeground(new java.awt.Color(0, 0, 0));

        jTextFieldUsername.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldUsername.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldUsername.setForeground(new java.awt.Color(0, 0, 0));

        jLabelslogan.setBackground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelslogan.setForeground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setText("Suponer lo peor y hacer lo mejor, es el método de un verdadero estratega.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelConfirmaPassword)
                            .addComponent(jLabelPassword)
                            .addComponent(jLabelNombreUsuario))
                        .addGap(56, 56, 56)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPasswordFieldPass, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                            .addComponent(jPasswordFieldPass1)
                            .addComponent(jTextFieldUsername, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jButtonRegresar)
                        .addGap(65, 65, 65)
                        .addComponent(jButtonContinuar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(jLabelslogan)))
                .addContainerGap(114, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombreUsuario)
                    .addComponent(jTextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelPassword)
                    .addComponent(jPasswordFieldPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPasswordFieldPass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelConfirmaPassword))
                .addGap(51, 51, 51)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonContinuar)
                    .addComponent(jButtonRegresar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jLabelslogan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 672, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelCloseMouseClicked

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jButtonRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonRegresarMouseClicked

    }//GEN-LAST:event_jButtonRegresarMouseClicked

    private void jButtonContinuarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonContinuarMouseClicked

    }//GEN-LAST:event_jButtonContinuarMouseClicked

    private void jButtonContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonContinuarActionPerformed
        Update();
        

    }//GEN-LAST:event_jButtonContinuarActionPerformed

    private void jButtonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegresarActionPerformed
        PAGINA_INICIO_SESION lp = new PAGINA_INICIO_SESION();
        lp.setVisible(true);
        lp.pack();
        lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButtonRegresarActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CAMBIAR_CLAVE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton jButtonContinuar;
    private javax.swing.JButton jButtonRegresar;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelConfirmaPassword;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelNombreUsuario;
    private javax.swing.JLabel jLabelOlvidadaPassword;
    private javax.swing.JLabel jLabelPassword;
    private javax.swing.JLabel jLabelicon;
    private javax.swing.JLabel jLabelslogan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordFieldPass;
    private javax.swing.JPasswordField jPasswordFieldPass1;
    public javax.swing.JTextField jTextFieldUsername;
    // End of variables declaration//GEN-END:variables
}
