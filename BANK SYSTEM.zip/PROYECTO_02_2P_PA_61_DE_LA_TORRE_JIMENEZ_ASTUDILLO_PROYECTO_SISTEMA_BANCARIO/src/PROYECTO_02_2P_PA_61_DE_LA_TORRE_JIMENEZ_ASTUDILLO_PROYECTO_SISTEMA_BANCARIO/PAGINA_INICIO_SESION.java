package PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO;
import java.sql.*;
import javax.swing.*;

public class PAGINA_INICIO_SESION extends javax.swing.JFrame {

    
    public PAGINA_INICIO_SESION() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    public static String u1;
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabeliniciarsesion = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jLabelicon = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelpassword = new javax.swing.JLabel();
        jLabelusuario = new javax.swing.JLabel();
        jTextFieldUsername = new javax.swing.JTextField();
        jPasswordFieldPass = new javax.swing.JPasswordField();
        jButtonCancel = new javax.swing.JButton();
        jButtonAcceder = new javax.swing.JButton();
        jLabelRegister = new javax.swing.JLabel();
        jLabelolvidado = new javax.swing.JLabel();
        jLabelslogan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(234, 62));

        jLabeliniciarsesion.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabeliniciarsesion.setForeground(new java.awt.Color(254, 254, 254));
        jLabeliniciarsesion.setText("INICIAR SESIÓN");

        jLabelClose.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(254, 254, 254));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(255, 250, 250));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jLabelicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO/icon.png"))); // NOI18N
        jLabelicon.setText("jLabel3");
        jLabelicon.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelicon, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabeliniciarsesion, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabelicon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelMin)
                            .addComponent(jLabeliniciarsesion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        jLabelpassword.setBackground(new java.awt.Color(236, 240, 241));
        jLabelpassword.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelpassword.setForeground(new java.awt.Color(0, 0, 0));
        jLabelpassword.setText("CONTRASEÑA:");

        jLabelusuario.setBackground(new java.awt.Color(236, 240, 241));
        jLabelusuario.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelusuario.setForeground(new java.awt.Color(0, 0, 0));
        jLabelusuario.setText("USUARIO:");

        jTextFieldUsername.setBackground(new java.awt.Color(108, 122, 137));
        jTextFieldUsername.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jTextFieldUsername.setForeground(new java.awt.Color(0, 0, 0));

        jPasswordFieldPass.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordFieldPass.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jPasswordFieldPass.setForeground(new java.awt.Color(0, 0, 0));

        jButtonCancel.setBackground(new java.awt.Color(0, 0, 0));
        jButtonCancel.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancel.setText("CANCELAR");
        jButtonCancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonCancelMouseClicked(evt);
            }
        });

        jButtonAcceder.setBackground(new java.awt.Color(0, 0, 0));
        jButtonAcceder.setFont(new java.awt.Font("Ubuntu Medium", 1, 14)); // NOI18N
        jButtonAcceder.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAcceder.setText("ACCEDER");
        jButtonAcceder.setPreferredSize(new java.awt.Dimension(105, 25));
        jButtonAcceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAccederMouseClicked(evt);
            }
        });
        jButtonAcceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAccederActionPerformed(evt);
            }
        });

        jLabelRegister.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelRegister.setForeground(new java.awt.Color(255, 0, 0));
        jLabelRegister.setText("CLICK PARA CREAR UNA CUENTA NUEVA");
        jLabelRegister.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelRegisterMouseClicked(evt);
            }
        });

        jLabelolvidado.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelolvidado.setForeground(new java.awt.Color(255, 0, 0));
        jLabelolvidado.setText("OLVIDÓ SU CONTRASEÑA?");
        jLabelolvidado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelolvidadoMouseClicked(evt);
            }
        });

        jLabelslogan.setBackground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelslogan.setForeground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setText("Suponer lo peor y hacer lo mejor, es el método de un verdadero estratega.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonCancel)
                        .addGap(65, 65, 65)
                        .addComponent(jButtonAcceder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabelpassword)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPasswordFieldPass, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                            .addComponent(jTextFieldUsername, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelolvidado))))
                .addGap(198, 198, 198))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(163, 163, 163)
                .addComponent(jLabelRegister)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelslogan)
                .addGap(83, 83, 83))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addComponent(jLabelusuario)
                    .addContainerGap(334, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jTextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelpassword)
                    .addComponent(jPasswordFieldPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jLabelolvidado)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAcceder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonCancel))
                .addGap(18, 18, 18)
                .addComponent(jLabelRegister)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jLabelslogan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(84, 84, 84)
                    .addComponent(jLabelusuario)
                    .addContainerGap(191, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 590, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelCloseMouseClicked

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jLabelRegisterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelRegisterMouseClicked
        REGISTRARSE rf=new REGISTRARSE();
        rf.setVisible(true);
        rf.pack();
        rf.setLocationRelativeTo(null);
        rf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jLabelRegisterMouseClicked

    private void jButtonCancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonCancelMouseClicked
        PAGINA_INICIO_SESION lp=new PAGINA_INICIO_SESION();
        lp.setVisible(true);
        lp.pack();
        lp.setLocationRelativeTo(null);
        lp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButtonCancelMouseClicked
    public void SetUsername(String u)
    {
        u1=u;
    }
    public String getUsername()
    {
        return u1;
    }
    private void jButtonAccederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAccederActionPerformed
        try
        {
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank2?autoReconnect=true","root","");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from User");
            String u=jTextFieldUsername.getText();
            String p=jPasswordFieldPass.getText();
            int flag=0;
            while(rs.next())
            {
                if((u.equals(rs.getString("Username")))  && (p.equals(rs.getString("Password"))))
                {
                   flag =1;
                }
            }
            if(flag == 1)
            {
                SetUsername(u);
                JOptionPane.showMessageDialog(null, "Sesión Iniciada Correctamente");
                INFORMACION_DETALLADA df = new INFORMACION_DETALLADA ();
                try
                {
                    Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank2?autoReconnect=true","root","");
                    String s1="";
                    String y=("Select FName from Customer where Username ='"+u+"' ");
                    Statement smt=mycon.createStatement();
                    PreparedStatement ps=mycon.prepareStatement(y);
                    ResultSet r=ps.executeQuery();
                    if(r.next())
                    {
                        s1=r.getString("FName");
                    }
                    df.set(s1);
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
                df.setVisible(true);
                df.pack();
                df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                this.dispose();  
            }
            else 
            {
                JOptionPane.showMessageDialog(null, "Porfavor Ingrese los Datos");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
       
    }//GEN-LAST:event_jButtonAccederActionPerformed

    private void jButtonAccederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAccederMouseClicked
    }//GEN-LAST:event_jButtonAccederMouseClicked

    private void jLabelolvidadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelolvidadoMouseClicked
        CAMBIAR_CLAVE up =new CAMBIAR_CLAVE();
        up.setVisible(true);
        up.pack();
        up.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jLabelolvidadoMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PAGINA_INICIO_SESION().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton jButtonAcceder;
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelRegister;
    private javax.swing.JLabel jLabelicon;
    private javax.swing.JLabel jLabeliniciarsesion;
    private javax.swing.JLabel jLabelolvidado;
    private javax.swing.JLabel jLabelpassword;
    private javax.swing.JLabel jLabelslogan;
    private javax.swing.JLabel jLabelusuario;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordFieldPass;
    public javax.swing.JTextField jTextFieldUsername;
    // End of variables declaration//GEN-END:variables
}
