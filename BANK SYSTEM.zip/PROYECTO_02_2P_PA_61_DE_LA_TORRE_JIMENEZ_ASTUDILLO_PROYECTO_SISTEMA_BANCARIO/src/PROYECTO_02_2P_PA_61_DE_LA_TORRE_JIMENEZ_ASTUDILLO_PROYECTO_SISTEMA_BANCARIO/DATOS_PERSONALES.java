package PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO;
import java.sql.*;
import javax.swing.*;

public class DATOS_PERSONALES extends javax.swing.JFrame {

    public static String u;
    
    public DATOS_PERSONALES() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    public void perform(String a,String b,String c,String d,String e,String f,String g,String h,String j)
    {
        jLabelFName.setText(a);
        jLabelLName.setText(b);
        jLabelAddress.setText(c);
        jLabelEmail.setText(d);
        jLabelPhone.setText(e);
        jLabelGender.setText(g);
        jLabelUserName.setText(h);
        jLabelIDUser.setText(j);
        jLabelDOB.setText(f);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelDatosPersonales = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jLabelicon = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelNombreUsuario = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jLabelDireccion = new javax.swing.JLabel();
        jLabelCorreo = new javax.swing.JLabel();
        jLabelTelefono = new javax.swing.JLabel();
        jLabelID = new javax.swing.JLabel();
        jLabelNacimiento = new javax.swing.JLabel();
        jLabelGenero = new javax.swing.JLabel();
        jButtonRegresar = new javax.swing.JButton();
        jLabelUserName = new javax.swing.JLabel();
        jLabelFName = new javax.swing.JLabel();
        jLabelLName = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jLabelAddress = new javax.swing.JLabel();
        jLabelPhone = new javax.swing.JLabel();
        jLabelIDUser = new javax.swing.JLabel();
        jLabelDOB = new javax.swing.JLabel();
        jLabelGender = new javax.swing.JLabel();
        jLabelslogan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(585, 62));

        jLabelDatosPersonales.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelDatosPersonales.setForeground(new java.awt.Color(254, 254, 254));
        jLabelDatosPersonales.setText("DATOS PERSONALES");

        jLabelClose.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelClose.setForeground(new java.awt.Color(254, 254, 254));
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Ubuntu Medium", 1, 24)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(255, 250, 250));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jLabelicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PROYECTO_02_2P_PA_61_DE_LA_TORRE_JIMENEZ_ASTUDILLO_PROYECTO_SISTEMA_BANCARIO/icon.png"))); // NOI18N
        jLabelicon.setText("jLabel3");
        jLabelicon.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelicon, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabelDatosPersonales, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDatosPersonales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelicon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabelNombreUsuario.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNombreUsuario.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelNombreUsuario.setForeground(new java.awt.Color(255, 0, 0));
        jLabelNombreUsuario.setText("NOMBRE DE USUARIO:");

        jLabelNombre.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNombre.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelNombre.setForeground(new java.awt.Color(255, 0, 0));
        jLabelNombre.setText("NOMBRE:");

        jLabelDireccion.setBackground(new java.awt.Color(236, 240, 241));
        jLabelDireccion.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelDireccion.setForeground(new java.awt.Color(255, 0, 0));
        jLabelDireccion.setText("DIRECCIÓN:");

        jLabelCorreo.setBackground(new java.awt.Color(236, 240, 241));
        jLabelCorreo.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelCorreo.setForeground(new java.awt.Color(255, 0, 0));
        jLabelCorreo.setText("E - MAIL:");

        jLabelTelefono.setBackground(new java.awt.Color(236, 240, 241));
        jLabelTelefono.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelTelefono.setForeground(new java.awt.Color(255, 0, 0));
        jLabelTelefono.setText("TELÉFONO:");

        jLabelID.setBackground(new java.awt.Color(236, 240, 241));
        jLabelID.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelID.setForeground(new java.awt.Color(255, 0, 0));
        jLabelID.setText("ID:");

        jLabelNacimiento.setBackground(new java.awt.Color(236, 240, 241));
        jLabelNacimiento.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelNacimiento.setForeground(new java.awt.Color(255, 0, 0));
        jLabelNacimiento.setText("FECHA DE NACIMIENTO:");

        jLabelGenero.setBackground(new java.awt.Color(236, 240, 241));
        jLabelGenero.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelGenero.setForeground(new java.awt.Color(255, 0, 0));
        jLabelGenero.setText("GÉNERO:");

        jButtonRegresar.setBackground(new java.awt.Color(255, 0, 0));
        jButtonRegresar.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jButtonRegresar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRegresar.setText("REGRESAR");
        jButtonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegresarActionPerformed(evt);
            }
        });

        jLabelUserName.setBackground(new java.awt.Color(236, 240, 241));
        jLabelUserName.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelUserName.setForeground(new java.awt.Color(0, 0, 0));

        jLabelFName.setBackground(new java.awt.Color(236, 240, 241));
        jLabelFName.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelFName.setForeground(new java.awt.Color(0, 0, 0));

        jLabelLName.setBackground(new java.awt.Color(236, 240, 241));
        jLabelLName.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelLName.setForeground(new java.awt.Color(0, 0, 0));

        jLabelEmail.setBackground(new java.awt.Color(236, 240, 241));
        jLabelEmail.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelEmail.setForeground(new java.awt.Color(0, 0, 0));

        jLabelAddress.setBackground(new java.awt.Color(236, 240, 241));
        jLabelAddress.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelAddress.setForeground(new java.awt.Color(0, 0, 0));

        jLabelPhone.setBackground(new java.awt.Color(236, 240, 241));
        jLabelPhone.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelPhone.setForeground(new java.awt.Color(0, 0, 0));

        jLabelIDUser.setBackground(new java.awt.Color(236, 240, 241));
        jLabelIDUser.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelIDUser.setForeground(new java.awt.Color(0, 0, 0));

        jLabelDOB.setBackground(new java.awt.Color(236, 240, 241));
        jLabelDOB.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelDOB.setForeground(new java.awt.Color(0, 0, 0));

        jLabelGender.setBackground(new java.awt.Color(236, 240, 241));
        jLabelGender.setFont(new java.awt.Font("Ubuntu Light", 1, 18)); // NOI18N
        jLabelGender.setForeground(new java.awt.Color(0, 0, 0));

        jLabelslogan.setBackground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setFont(new java.awt.Font("Ubuntu Light", 1, 12)); // NOI18N
        jLabelslogan.setForeground(new java.awt.Color(0, 0, 0));
        jLabelslogan.setText("Suponer lo peor y hacer lo mejor, es el método de un verdadero estratega.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelGenero)
                    .addComponent(jLabelNacimiento)
                    .addComponent(jLabelID)
                    .addComponent(jLabelCorreo)
                    .addComponent(jLabelDireccion)
                    .addComponent(jLabelNombre)
                    .addComponent(jLabelNombreUsuario)
                    .addComponent(jLabelTelefono))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabelFName, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelLName, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabelEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                    .addComponent(jLabelAddress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelPhone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelIDUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelDOB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelGender, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelslogan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jButtonRegresar)
                .addGap(44, 44, 44))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelNombreUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelUserName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                    .addComponent(jLabelFName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelLName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelAddress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelPhone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelIDUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelDOB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelGenero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelGender, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButtonRegresar)
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabelslogan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegresarActionPerformed
        INFORMACION_DETALLADA di=new INFORMACION_DETALLADA();
        di.setVisible(true);
        di.pack();
        di.setLocationRelativeTo(null);
        di.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButtonRegresarActionPerformed

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelCloseMouseClicked

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DATOS_PERSONALES().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonRegresar;
    private javax.swing.JLabel jLabelAddress;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelCorreo;
    private javax.swing.JLabel jLabelDOB;
    private javax.swing.JLabel jLabelDatosPersonales;
    private javax.swing.JLabel jLabelDireccion;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelFName;
    private javax.swing.JLabel jLabelGender;
    private javax.swing.JLabel jLabelGenero;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelIDUser;
    private javax.swing.JLabel jLabelLName;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelNacimiento;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelNombreUsuario;
    private javax.swing.JLabel jLabelPhone;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelUserName;
    private javax.swing.JLabel jLabelicon;
    private javax.swing.JLabel jLabelslogan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
